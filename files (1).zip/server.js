/**
 * Malipo Yetu — Express Backend
 * Handles Pi Network U2A (User-to-App) payment approval and completion
 * for utility bill payments (electricity, water, mobile top-up, insurance,
 * school fees, rent, etc.).
 *
 * Required environment variables (set in .env — never hardcode):
 *   PI_NETWORK_API_KEY   — Your app's server-side Pi API key from
 *                          https://developers.minepi.com (Developer Portal)
 *
 * Optional:
 *   PORT                 — HTTP port (default 3000)
 *   PI_EXCHANGE_RATE     — TZS per 1 Pi (default 1000). Override this with
 *                          a live rate from your preferred exchange source.
 *   SANDBOX              — Set to "true" during development
 *
 * Install:
 *   npm install express dotenv cors
 */

'use strict';

require('dotenv').config();

const express = require('express');
const cors    = require('cors');
const path    = require('path');

const app  = express();
const PORT = process.env.PORT || 3000;

// ── Env validation ─────────────────────────────────────────────────────────
const PI_API_KEY = process.env.PI_NETWORK_API_KEY;
if (!PI_API_KEY) {
  console.error(
    '\n[FATAL] PI_NETWORK_API_KEY is not set.\n' +
    'Create a .env file with:\n' +
    '  PI_NETWORK_API_KEY=your_key_from_developer_portal\n' +
    'Get your key at https://developers.minepi.com\n'
  );
  process.exit(1);
}

// TZS per 1 Pi — adjust or replace with a live exchange rate source
const PI_EXCHANGE_RATE = parseFloat(process.env.PI_EXCHANGE_RATE) || 1000;

// Pi Platform API base URL
const PI_API_BASE = 'https://api.minepi.com/v2';

// ── Middleware ──────────────────────────────────────────────────────────────
app.use(cors());
app.use(express.json());

// Serve the single-file frontend from the same directory
app.use(express.static(path.join(__dirname)));

// ── Helper — call Pi Platform API with server API key ──────────────────────
async function piRequest(method, endpoint, body) {
  const res = await fetch(`${PI_API_BASE}${endpoint}`, {
    method,
    headers: {
      'Authorization': `Key ${PI_API_KEY}`,
      'Content-Type':  'application/json',
    },
    ...(body ? { body: JSON.stringify(body) } : {}),
  });

  const text = await res.text();
  let json;
  try { json = JSON.parse(text); } catch { json = { raw: text }; }

  if (!res.ok) {
    const err = new Error(`Pi API ${endpoint} → ${res.status}`);
    err.status  = res.status;
    err.piError = json;
    throw err;
  }
  return json;
}

// ── POST /api/payments/quote ────────────────────────────────────────────────
// Frontend calls this before Pi.createPayment to get the server-authoritative
// Pi amount. Prevents the client from spoofing the price.
//
// Body:  { tzs_amount: number, service: string, serviceRef: string }
// Reply: { pi_amount: number, tzs_amount: number, rate: number }
app.post('/api/payments/quote', (req, res) => {
  const { tzs_amount, service, serviceRef } = req.body;

  if (!tzs_amount || typeof tzs_amount !== 'number' || tzs_amount <= 0) {
    return res.status(400).json({ error: 'Invalid tzs_amount' });
  }
  if (!service || !serviceRef) {
    return res.status(400).json({ error: 'service and serviceRef are required' });
  }

  // Round to 4 decimal places (Pi SDK minimum precision)
  const pi_amount = parseFloat((tzs_amount / PI_EXCHANGE_RATE).toFixed(4));

  return res.json({
    pi_amount,
    tzs_amount,
    rate: PI_EXCHANGE_RATE,
  });
});

// ── POST /api/payments/approve ──────────────────────────────────────────────
// Called by the frontend's onReadyForServerApproval callback.
// The server calls Pi Platform to approve the payment before the user signs.
//
// Body:  { paymentId: string }
// Reply: Pi Platform approval response
app.post('/api/payments/approve', async (req, res) => {
  const { paymentId } = req.body;

  if (!paymentId || typeof paymentId !== 'string') {
    return res.status(400).json({ error: 'paymentId is required' });
  }

  try {
    // ① Fetch the payment from Pi to validate it before approving
    const payment = await piRequest('GET', `/payments/${paymentId}`);

    // ② Verify the payment amount matches what the server expects.
    //    This is the key security check — the client cannot inflate the price.
    //    We re-derive the expected Pi amount from the metadata.
    const { metadata } = payment;
    if (metadata?.tzs_amount) {
      const expectedPi = parseFloat((metadata.tzs_amount / PI_EXCHANGE_RATE).toFixed(4));
      const actualPi   = parseFloat(payment.amount);
      // Allow a small rounding tolerance (0.001 Pi)
      if (Math.abs(actualPi - expectedPi) > 0.001) {
        console.error('Payment amount mismatch:', { actualPi, expectedPi, paymentId });
        return res.status(400).json({ error: 'Payment amount mismatch — possible tampering' });
      }
    }

    // ③ Approve the payment on Pi Platform
    const approval = await piRequest('POST', `/payments/${paymentId}/approve`);

    console.log(`[APPROVED] paymentId=${paymentId} service=${metadata?.service} ref=${metadata?.serviceRef}`);

    // ④ Here you would record the pending payment in your database
    //    e.g.: await db.payments.create({ paymentId, status: 'approved', metadata });

    return res.json(approval);

  } catch (err) {
    console.error('[approve] Error:', err.message, err.piError);
    return res.status(err.status || 500).json({
      error:   err.message,
      details: err.piError,
    });
  }
});

// ── POST /api/payments/complete ─────────────────────────────────────────────
// Called by the frontend's onReadyForServerCompletion callback AND by
// onIncompletePaymentFound to resolve in-flight payments after a crash.
//
// Body:  { paymentId: string, txid: string | null }
// Reply: Pi Platform completion response
app.post('/api/payments/complete', async (req, res) => {
  const { paymentId, txid } = req.body;

  if (!paymentId || typeof paymentId !== 'string') {
    return res.status(400).json({ error: 'paymentId is required' });
  }

  try {
    // ① Re-fetch the payment from Pi to confirm current status
    const payment = await piRequest('GET', `/payments/${paymentId}`);

    // ② Use the txid from the blockchain if the client didn't supply one
    //    (this happens when recovering an incomplete payment found at auth time)
    const resolvedTxid = txid || payment.transaction?.txid;

    if (!resolvedTxid) {
      // Blockchain hasn't confirmed yet — not safe to complete
      console.warn(`[complete] No txid yet for paymentId=${paymentId}, skipping`);
      return res.status(202).json({ status: 'pending', message: 'Blockchain confirmation pending' });
    }

    // ③ Tell Pi Platform to move the Pi to the app wallet
    const completion = await piRequest('POST', `/payments/${paymentId}/complete`, { txid: resolvedTxid });

    console.log(`[COMPLETED] paymentId=${paymentId} txid=${resolvedTxid} service=${payment.metadata?.service}`);

    // ④ Here you would:
    //    a) Mark the payment as completed in your database
    //    b) Trigger the actual utility bill payment via your provider API
    //    c) Send an SMS/email confirmation to the user
    //
    // Example (uncomment and adapt):
    // await db.payments.update({ paymentId }, { status: 'completed', txid: resolvedTxid });
    // await utilityProvider.pay({
    //   service:    payment.metadata.service,
    //   ref:        payment.metadata.serviceRef,
    //   tzs_amount: payment.metadata.tzs_amount,
    // });

    return res.json(completion);

  } catch (err) {
    console.error('[complete] Error:', err.message, err.piError);
    return res.status(err.status || 500).json({
      error:   err.message,
      details: err.piError,
    });
  }
});

// ── Catch-all → serve the SPA ───────────────────────────────────────────────
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'MalipoYetu_WebApp.html'));
});

// ── Start ───────────────────────────────────────────────────────────────────
app.listen(PORT, () => {
  console.log(`\n✅ Malipo Yetu server running on http://localhost:${PORT}`);
  console.log(`   Pi exchange rate: 1 Pi = TZS ${PI_EXCHANGE_RATE}`);
  console.log(`   Sandbox mode: ${process.env.SANDBOX === 'true' ? 'YES' : 'NO'}\n`);
});
